#include<iostream>
using namespace std;
int main()
{
	int temp = 0, count1 = 0, count2 = 0;
	const int size = 30;
	int array[size] = { 0 };
	int sort[size] = { 0 };
	int even[size] = { 0 };
	int reverse[size] = { 0 };
	int prime[size] = { 0 };
	//---->	Taking values of array from user.
	for (int i = 0; i <size; i++)
	{
		cout << "Enter a number in array " << i + 1 << " = ";
		cin >> array[i];
	}
	//--->Going to swap for sorting .
	for (int i = 0; i <size; i++)
	{
		sort[i] = array[i];//copying elements of one array named array in another array named sort. 
	}
	//--->Sorting starts.
	for (int i = 0; i<size; i++)
	{
		for (int j = 0; j<size; j++)
		{
			if (sort[j] < sort[j + 1])//applying condition to check the descending order.
			{
				temp = sort[j];
				sort[j] = sort[j + 1];
				sort[j+1] = temp;
			}
		}
	}
	cout << "After sorting in descending order :" << endl;
	//Displaying sorted array.
	for (int i = 0; i <size; i++)
	{
		cout << sort[i]<<"\t";
	}
	//step 1 completed step 2 is starting .
	//Now removing of even intergers process from array
	for (int i = 0; i<size; i++)
	{
		if (!(sort[i] % 2 == 0))//verified condition will give you odd numbers 
		{
		    even[count1] = sort[i];
			count1++;
		}
	}
	cout << endl;
	//Displaying removed even numbers array:
	cout << "Removing even numbers from sorted array:" << endl;
	for (int i = 0; i <count1; i++)
	{
		cout<< even[i]<<"\t";
	}
	cout << endl;
	//step2 completed and starting the step number 3 
	//Swap removed even numbers  array to reverse array.
	for (int i = 0; i<count1; i++)
	{
		reverse[i] = even[i];//copying elements of removed even array into another new array named reverse. 
	}
	//After swapping(copying),reversing that array:
	for (int i = 0; i <size; i++)
	{
		for (int j = 0; j<count1 - 1; j++)
		{
			if (reverse[j] >reverse[j + 1])
			{
				temp = reverse[j];
				reverse[j] = reverse[j + 1];
				reverse[j + 1] = temp;//array is reversed by swapping method 
			}
		}
	}
	//Displaying reversed array having removed even numbers:
	cout << "After reverse the array having removed even numbers:" << endl;
	for (int i = 0; i <count1; i++)
	{
		cout << " " << reverse[i];
	}
	//step3 completed and step 4 is starting 
	//Now removing the numbers which are not prime:
	for (int i = 0; i <count1; i++)
	{
		int j = 0;
		for (j = reverse[i] - 1; j>0; j--)
		{
			if (reverse[i] % j == 0)
			{
				break;
			}
		}
		if (j == 1)
		{
			prime[count2] = reverse[i];
			count2++;
		}
	}
	cout << endl; 
	//Displaying prime numbers of array after removal numbers which are not prime :
	cout << "After removing the numbers which are not prime:" << endl;
	for (int i = 0; i <count2; i++)
	{
		cout << prime[i]<<"\t";
	}
	cout << endl;
	//step 4 is completed and 5 is started
	//Swapping of first and last digit of array having removed even numbers and numbers which are not prime : 
	temp = prime[0];
	prime[0] = prime[count2 - 1];
	prime[count2 - 1] = temp;
	cout << "After swapping of first and last digit:" << endl;
	for (int i = 0; i <count2; i++)
	{
		cout << prime[i]<<"\t";
	}
	cout << endl;
	return 0;
}